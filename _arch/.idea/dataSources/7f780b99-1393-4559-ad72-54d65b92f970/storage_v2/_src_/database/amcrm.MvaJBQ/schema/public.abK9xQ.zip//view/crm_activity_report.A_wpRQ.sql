create view crm_activity_report(id, subtype_id, mail_activity_type_id, author_id, date, subject, lead_id, user_id, team_id, country_id, company_id, stage_id, partner_id, lead_type, active, probability) as
SELECT m.id,
       m.subtype_id,
       m.mail_activity_type_id,
       m.author_id,
       m.date,
       m.subject,
       l.id   AS lead_id,
       l.user_id,
       l.team_id,
       l.country_id,
       l.company_id,
       l.stage_id,
       l.partner_id,
       l.type AS lead_type,
       l.active,
       l.probability
FROM mail_message m
         JOIN crm_lead l ON m.res_id = l.id
WHERE m.model::text = 'crm.lead'::text
  AND m.mail_activity_type_id IS NOT NULL;

alter table crm_activity_report
    owner to ra;

