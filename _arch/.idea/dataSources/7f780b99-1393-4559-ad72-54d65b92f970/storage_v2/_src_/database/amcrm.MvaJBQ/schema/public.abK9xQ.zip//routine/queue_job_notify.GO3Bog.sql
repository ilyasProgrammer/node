create function queue_job_notify() returns trigger
    language plpgsql
as
$$
BEGIN
                    IF TG_OP = 'DELETE' THEN
                        IF OLD.state != 'done' THEN
                            PERFORM pg_notify('queue_job', OLD.uuid);
                        END IF;
                    ELSE
                        PERFORM pg_notify('queue_job', NEW.uuid);
                    END IF;
                    RETURN NULL;
                END;
$$;

alter function queue_job_notify() owner to ra;

